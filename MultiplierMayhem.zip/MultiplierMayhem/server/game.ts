import { WebSocket, WebSocketServer } from "ws";
import { storage } from "./storage";
import { rng } from "./rng";
import { 
  GameState, WSMessage, User, Game, Bet, LivePlayer 
} from "@shared/schema";
import { Server } from "http";

/**
 * Main game controller for the multiplier game
 * Handles game state, betting, and WebSocket communication
 */
export class GameController {
  private wss: WebSocketServer | null = null;
  private clients: Map<WebSocket, { userId?: number, username?: string }> = new Map();
  private gameState: GameState = GameState.WAITING;
  private currentGame: Game | null = null;
  private nextGameStart: number = 0;
  private activeBets: Map<number, Bet> = new Map(); // userId -> bet
  private crashTimer: NodeJS.Timeout | null = null;
  private countdownTimer: NodeJS.Timeout | null = null;
  private currentMultiplier: number = 1.00;

  // Game constants
  private readonly COUNTDOWN_SECONDS = 5;
  private readonly TICK_INTERVAL_MS = 100;
  private readonly MAX_MULTIPLIER = 1000; // Safety limit

  /**
   * Initialize the WebSocket server and start the game loop
   */
  initialize(server: Server) {
    // Create WebSocket server
    this.wss = new WebSocketServer({ server, path: "/ws" });

    // Handle connections
    this.wss.on("connection", (ws) => {
      this.clients.set(ws, {});
      console.log(`Client connected. Total clients: ${this.clients.size}`);

      // Send current game state to the new client
      this.sendGameState(ws);

      // Handle client messages
      ws.on("message", (message) => this.handleMessage(ws, message));

      // Handle disconnections
      ws.on("close", () => {
        this.clients.delete(ws);
        console.log(`Client disconnected. Total clients: ${this.clients.size}`);
      });
    });

    // Start the first game
    this.startNextGame();
  }

  /**
   * Process a message from a client
   */
  private handleMessage(ws: WebSocket, data: any) {
    try {
      const message: WSMessage = JSON.parse(data.toString());
      
      switch (message.type) {
        case "auth":
          this.handleAuth(ws, message.data.userId, message.data.username);
          break;
        
        case "place_bet":
          this.handlePlaceBet(ws, message.data.amount, message.data.autoCashout);
          break;
        
        case "cashout":
          this.handleCashout(ws);
          break;
          
        default:
          console.log(`Unknown message type: ${message.type}`);
      }
    } catch (err) {
      console.error("Error processing message:", err);
    }
  }

  /**
   * Associate a WebSocket client with a user
   */
  private handleAuth(ws: WebSocket, userId: number, username: string) {
    this.clients.set(ws, { userId, username });
    console.log(`User authenticated: ${username} (${userId})`);

    // Send updated stats to the user
    this.sendUserData(ws);
  }

  /**
   * Handle a new bet from a client
   */
  private async handlePlaceBet(ws: WebSocket, amount: number, autoCashout?: number) {
    const client = this.clients.get(ws);
    if (!client || !client.userId) {
      this.sendError(ws, "You must be logged in to place a bet");
      return;
    }

    // Only allow bets during the STARTING phase or early in ACTIVE
    if (this.gameState !== GameState.STARTING && 
        (this.gameState !== GameState.ACTIVE || this.currentMultiplier > 1.1)) {
      this.sendError(ws, "Betting is closed for this round");
      return;
    }

    if (!this.currentGame) {
      this.sendError(ws, "No active game");
      return;
    }

    try {
      // Check if user already has an active bet
      if (this.activeBets.has(client.userId)) {
        this.sendError(ws, "You already have an active bet");
        return;
      }

      // Validate bet amount
      if (amount <= 0) {
        this.sendError(ws, "Bet amount must be positive");
        return;
      }

      // Get user
      const user = await storage.getUser(client.userId);
      if (!user) {
        this.sendError(ws, "User not found");
        return;
      }

      // Check if user has enough balance
      if (user.balance < amount) {
        this.sendError(ws, "Insufficient balance");
        return;
      }

      // Update user balance
      await storage.updateUserBalance(client.userId, user.balance - amount);

      // Create bet
      const bet = await storage.createBet({
        userId: client.userId,
        gameId: this.currentGame.id,
        amount,
        autoCashoutAt: autoCashout,
        cashedOutAt: null,
        profit: null
      });

      // Store bet reference
      this.activeBets.set(client.userId, bet);

      // Send updated user data
      this.sendUserData(ws);

      // Broadcast updated player list
      this.broadcastLivePlayers();
    } catch (err) {
      console.error("Error placing bet:", err);
      this.sendError(ws, "Failed to place bet");
    }
  }

  /**
   * Handle a cashout request from a client
   */
  private async handleCashout(ws: WebSocket) {
    const client = this.clients.get(ws);
    if (!client || !client.userId) {
      this.sendError(ws, "You must be logged in to cash out");
      return;
    }

    // Can only cash out during active game
    if (this.gameState !== GameState.ACTIVE) {
      this.sendError(ws, "Cannot cash out at this time");
      return;
    }

    // Check if user has an active bet
    const bet = this.activeBets.get(client.userId);
    if (!bet) {
      this.sendError(ws, "No active bet to cash out");
      return;
    }

    try {
      // Calculate profit
      const profit = bet.amount * (this.currentMultiplier - 1);
      const winnings = bet.amount + profit;

      // Update user balance
      const user = await storage.getUser(client.userId);
      if (!user) {
        this.sendError(ws, "User not found");
        return;
      }
      await storage.updateUserBalance(client.userId, user.balance + winnings);

      // Update bet
      await storage.updateBet(bet.id, this.currentMultiplier, profit);

      // Remove from active bets
      this.activeBets.delete(client.userId);

      // Send updated user data
      this.sendUserData(ws);

      // Broadcast updated player list
      this.broadcastLivePlayers();
    } catch (err) {
      console.error("Error cashing out:", err);
      this.sendError(ws, "Failed to cash out");
    }
  }

  /**
   * Start a new game
   */
  private startNextGame() {
    // Reset game state
    this.gameState = GameState.STARTING;
    this.currentMultiplier = 1.00;
    this.activeBets.clear();

    // Generate provably fair crash point
    const serverSeed = rng.generateServerSeed();
    const hash = rng.generateHash(serverSeed);
    const crashPoint = rng.calculateCrashPoint(serverSeed);

    // Create new game in storage
    storage.createGame({
      crashPoint,
      seed: serverSeed,
      hash
    }).then(game => {
      this.currentGame = game;
      console.log(`New game started: ID=${game.id}, Crash Point=${crashPoint}`);
      
      // Broadcast game state to clients
      this.broadcastGameState();
      
      // Start countdown
      this.startCountdown();
    }).catch(err => {
      console.error("Failed to create game:", err);
      // Retry after a delay
      setTimeout(() => this.startNextGame(), 1000);
    });
  }

  /**
   * Start the countdown before the active phase
   */
  private startCountdown() {
    let countdown = this.COUNTDOWN_SECONDS;
    this.nextGameStart = Date.now() + countdown * 1000;
    
    // Send countdown updates
    const sendUpdate = () => {
      this.broadcast({
        type: "countdown",
        data: { countdown }
      });
    };
    
    sendUpdate();
    
    // Clear any existing timers
    if (this.countdownTimer) clearInterval(this.countdownTimer);
    
    // Set timer to count down every second
    this.countdownTimer = setInterval(() => {
      countdown--;
      sendUpdate();
      
      if (countdown <= 0) {
        clearInterval(this.countdownTimer!);
        this.startActiveGame();
      }
    }, 1000);
  }

  /**
   * Start the active phase where the multiplier increases
   */
  private startActiveGame() {
    // Update game state
    this.gameState = GameState.ACTIVE;
    this.currentMultiplier = 1.00;
    
    // Broadcast state change
    this.broadcastGameState();
    
    // Clear any existing timer
    if (this.crashTimer) clearInterval(this.crashTimer);
    
    // Set timer to increase multiplier
    const startTime = Date.now();
    const crashTime = this.calculateCrashTime();
    
    this.crashTimer = setInterval(() => {
      const elapsed = Date.now() - startTime;
      // If crashed or reached safety limit
      if (elapsed >= crashTime || this.currentMultiplier >= this.MAX_MULTIPLIER) {
        this.handleGameCrash();
        return;
      }
      
      // Update multiplier (non-linear growth)
      this.currentMultiplier = this.calculateMultiplier(elapsed);
      
      // Process auto-cashouts
      this.processAutoCashouts();
      
      // Broadcast current multiplier
      this.broadcast({
        type: "multiplier",
        data: { multiplier: this.currentMultiplier }
      });
    }, this.TICK_INTERVAL_MS);
  }

  /**
   * Handle game crash
   */
  private handleGameCrash() {
    // Stop the interval
    if (this.crashTimer) {
      clearInterval(this.crashTimer);
      this.crashTimer = null;
    }
    
    // Update game state
    this.gameState = GameState.CRASHED;
    
    // Process remaining bets as losses
    this.finalizeLosses();
    
    // Broadcast crash
    this.broadcastGameState();
    
    // Schedule next game after a delay
    setTimeout(() => {
      this.startNextGame();
    }, 3000);
  }

  /**
   * Process any auto-cashouts at the current multiplier
   */
  private processAutoCashouts() {
    for (const [userId, bet] of this.activeBets.entries()) {
      if (bet.autoCashoutAt && this.currentMultiplier >= bet.autoCashoutAt) {
        this.processAutoCashout(userId, bet);
      }
    }
  }

  /**
   * Process a specific auto-cashout
   */
  private async processAutoCashout(userId: number, bet: Bet) {
    try {
      // Calculate profit
      const profit = bet.amount * (this.currentMultiplier - 1);
      const winnings = bet.amount + profit;
      
      // Update user balance
      const user = await storage.getUser(userId);
      if (user) {
        await storage.updateUserBalance(userId, user.balance + winnings);
      }
      
      // Update bet
      await storage.updateBet(bet.id, this.currentMultiplier, profit);
      
      // Remove from active bets
      this.activeBets.delete(userId);
      
      // Broadcast updated player list
      this.broadcastLivePlayers();
      
      // Send notification to the specific user
      this.notifyUser(userId, {
        type: "cashout",
        data: {
          multiplier: this.currentMultiplier,
          amount: bet.amount,
          profit: profit
        }
      });
    } catch (err) {
      console.error(`Error processing auto-cashout for user ${userId}:`, err);
    }
  }

  /**
   * Finalize all remaining bets as losses when the game crashes
   */
  private async finalizeLosses() {
    const promises = [];
    for (const [userId, bet] of this.activeBets.entries()) {
      promises.push(
        storage.updateBet(bet.id, null, -bet.amount)
          .catch(err => console.error(`Error finalizing loss for user ${userId}:`, err))
      );
    }
    
    try {
      await Promise.all(promises);
    } catch (err) {
      console.error("Error finalizing losses:", err);
    }
    
    // Clear active bets
    this.activeBets.clear();
  }

  /**
   * Calculate the current multiplier based on elapsed time
   */
  private calculateMultiplier(elapsedMs: number) {
    // Use a growth function that starts slow and accelerates
    // This formula gives a smoother, more engaging growth curve
    const baseGrowth = 0.0005; // Base growth per millisecond
    const accelerationFactor = 0.0000002; // How quickly the growth accelerates
    
    const seconds = elapsedMs / 1000;
    const multiplier = 1 + (baseGrowth * elapsedMs) + (accelerationFactor * Math.pow(elapsedMs, 1.5));
    
    // Round to 2 decimal places
    return Math.floor(multiplier * 100) / 100;
  }

  /**
   * Calculate the time in ms when the game should crash based on the crash point
   */
  private calculateCrashTime() {
    if (!this.currentGame) return 5000; // Fallback
    
    // Inverse of the multiplier calculation to get the time for a specific crash point
    const targetMultiplier = this.currentGame.crashPoint;
    const baseGrowth = 0.0005;
    const accelerationFactor = 0.0000002;
    
    // Simplified estimation (not exact, but close enough)
    // For more accuracy, we would need to solve the equation analytically
    const growthNeeded = targetMultiplier - 1;
    const approxTime = growthNeeded / baseGrowth * 1000;
    
    return approxTime;
  }

  /**
   * Send the current game state to a specific client
   */
  private sendGameState(ws: WebSocket) {
    if (ws.readyState !== WebSocket.OPEN) return;
    
    try {
      ws.send(JSON.stringify({
        type: "game_state",
        data: {
          state: this.gameState,
          multiplier: this.currentMultiplier,
          nextGameStart: this.nextGameStart,
          gameId: this.currentGame?.id,
          hash: this.currentGame?.hash
        }
      }));
    } catch (err) {
      console.error("Error sending game state:", err);
    }
  }

  /**
   * Broadcast the current game state to all clients
   */
  private broadcastGameState() {
    this.broadcast({
      type: "game_state",
      data: {
        state: this.gameState,
        multiplier: this.currentMultiplier,
        nextGameStart: this.nextGameStart,
        gameId: this.currentGame?.id,
        hash: this.currentGame?.hash
      }
    });
    
    // Also broadcast live players
    this.broadcastLivePlayers();
  }

  /**
   * Broadcast the current list of live players to all clients
   */
  private async broadcastLivePlayers() {
    try {
      const players: LivePlayer[] = [];
      
      for (const [userId, bet] of this.activeBets.entries()) {
        const user = await storage.getUser(userId);
        if (user) {
          players.push({
            id: userId,
            username: user.username,
            bet: bet.amount,
            autoCashout: bet.autoCashoutAt,
            cashedOut: bet.cashedOutAt,
            profit: bet.profit
          });
        }
      }
      
      this.broadcast({
        type: "live_players",
        data: { players }
      });
    } catch (err) {
      console.error("Error broadcasting live players:", err);
    }
  }

  /**
   * Send user-specific data to a client
   */
  private async sendUserData(ws: WebSocket) {
    const client = this.clients.get(ws);
    if (!client || !client.userId) return;
    
    try {
      const user = await storage.getUser(client.userId);
      const stats = await storage.getUserStats(client.userId);
      
      if (ws.readyState === WebSocket.OPEN && user) {
        ws.send(JSON.stringify({
          type: "user_data",
          data: {
            user: {
              id: user.id,
              username: user.username,
              balance: user.balance
            },
            stats
          }
        }));
      }
    } catch (err) {
      console.error("Error sending user data:", err);
    }
  }

  /**
   * Notify a specific user with a message
   */
  private notifyUser(userId: number, message: any) {
    for (const [ws, client] of this.clients.entries()) {
      if (client.userId === userId && ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(JSON.stringify(message));
        } catch (err) {
          console.error("Error notifying user:", err);
        }
      }
    }
  }

  /**
   * Send an error message to a client
   */
  private sendError(ws: WebSocket, message: string) {
    if (ws.readyState !== WebSocket.OPEN) return;
    
    try {
      ws.send(JSON.stringify({
        type: "error",
        data: { message }
      }));
    } catch (err) {
      console.error("Error sending error message:", err);
    }
  }

  /**
   * Broadcast a message to all connected clients
   */
  private broadcast(message: any) {
    const data = JSON.stringify(message);
    
    for (const [ws, _] of this.clients.entries()) {
      if (ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(data);
        } catch (err) {
          console.error("Error broadcasting message:", err);
        }
      }
    }
  }
}

export const gameController = new GameController();
