import crypto from "crypto";

/**
 * Implements a provably fair RNG system similar to ones used in crypto casinos
 * The algorithm works as follows:
 * 1. Generate a server seed and hash it to create a game hash
 * 2. Reveal the server seed after the game for verification
 * 3. Calculate crash point using HMAC with the seed
 */
export class ProvablyFairRNG {
  private readonly HOUSE_EDGE = 0.01; // 1% house edge

  /**
   * Generate a random server seed for a new game
   */
  generateServerSeed(): string {
    return crypto.randomBytes(32).toString("hex");
  }

  /**
   * Hash a server seed to get a game hash that can be shown before revealing the seed
   */
  generateHash(serverSeed: string): string {
    return crypto.createHash("sha256").update(serverSeed).digest("hex");
  }

  /**
   * Calculate the crash point using HMAC-SHA256
   * Formula: (100 / (1-HOUSE_EDGE)) / (float in range [0, 1) from HMAC)
   * This creates an exponential distribution with a house edge
   */
  calculateCrashPoint(serverSeed: string): number {
    // Generate HMAC using SHA256
    const hmac = crypto.createHmac("sha256", serverSeed).update("crash_game").digest("hex");
    
    // Use first 8 characters of HMAC (4 bytes) to create a float in range [0, 1)
    const hex = hmac.slice(0, 8);
    // Convert the hex to a number and normalize to [0, 1)
    const decimal = parseInt(hex, 16) / Math.pow(2, 32);
    
    // Skip the 1% of crash points that would lead to a value of 1.00 or less
    if (decimal < this.HOUSE_EDGE) {
      // Try again with a modified seed
      return this.calculateCrashPoint(serverSeed + "retry");
    }
    
    // Calculate the crash point with 1% house edge
    // The formula gives a minimum of 1.00 and follows an exponential curve
    const crashPoint = Math.max(1.00, 100 / decimal / (1 / (1 - this.HOUSE_EDGE)));
    
    // Round to 2 decimal places
    return Math.floor(crashPoint * 100) / 100;
  }

  /**
   * Verify that a crash point was calculated fairly using the revealed server seed
   */
  verifyCrashPoint(serverSeed: string, givenCrashPoint: number): boolean {
    const calculatedCrashPoint = this.calculateCrashPoint(serverSeed);
    return Math.abs(calculatedCrashPoint - givenCrashPoint) < 0.001; // Allow for floating point errors
  }
}

export const rng = new ProvablyFairRNG();
