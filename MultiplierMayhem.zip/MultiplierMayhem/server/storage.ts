import { 
  User, InsertUser, Game, InsertGame, Bet, InsertBet, 
  LivePlayer, GameStats, UserStats
} from "@shared/schema";
import * as schema from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: number, newBalance: number): Promise<User>;

  // Game operations
  createGame(game: InsertGame): Promise<Game>;
  getGameById(id: number): Promise<Game | undefined>;
  getRecentGames(limit: number): Promise<Game[]>;
  getGameStats(count: number): Promise<GameStats>;

  // Bet operations
  createBet(bet: InsertBet): Promise<Bet>;
  updateBet(id: number, cashedOutAt: number, profit: number): Promise<Bet>;
  getBetsByGameId(gameId: number): Promise<Bet[]>;
  getBetsByUserId(userId: number): Promise<Bet[]>;
  getUserStats(userId: number): Promise<UserStats>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private games: Map<number, Game>;
  private bets: Map<number, Bet>;
  private currentUserId: number;
  private currentGameId: number;
  private currentBetId: number;

  constructor() {
    this.users = new Map();
    this.games = new Map();
    this.bets = new Map();
    this.currentUserId = 1;
    this.currentGameId = 1;
    this.currentBetId = 1;

    // Add default user
    this.createUser({
      username: "Player123",
      password: "password123",
      balance: 10000
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  async updateUserBalance(userId: number, newBalance: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = { ...user, balance: newBalance };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Game operations
  async createGame(game: InsertGame): Promise<Game> {
    const id = this.currentGameId++;
    const createdAt = new Date();
    const newGame: Game = { ...game, id, createdAt };
    this.games.set(id, newGame);
    return newGame;
  }

  async getGameById(id: number): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async getRecentGames(limit: number): Promise<Game[]> {
    return Array.from(this.games.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async getGameStats(count: number): Promise<GameStats> {
    const recentGames = await this.getRecentGames(count);
    if (recentGames.length === 0) {
      return {
        highestMultiplier: 0,
        averageMultiplier: 0,
        distribution: {
          low: 0,
          medium: 0,
          high: 0,
          extreme: 0
        }
      };
    }

    const multipliers = recentGames.map(game => game.crashPoint);
    const highestMultiplier = Math.max(...multipliers);
    const averageMultiplier = multipliers.reduce((a, b) => a + b, 0) / multipliers.length;

    let low = 0, medium = 0, high = 0, extreme = 0;
    for (const mult of multipliers) {
      if (mult < 2) low++;
      else if (mult < 4) medium++;
      else if (mult < 10) high++;
      else extreme++;
    }

    return {
      highestMultiplier,
      averageMultiplier,
      distribution: {
        low: Math.round((low / multipliers.length) * 100),
        medium: Math.round((medium / multipliers.length) * 100),
        high: Math.round((high / multipliers.length) * 100),
        extreme: Math.round((extreme / multipliers.length) * 100)
      }
    };
  }

  // Bet operations
  async createBet(bet: InsertBet): Promise<Bet> {
    const id = this.currentBetId++;
    const createdAt = new Date();
    const newBet: Bet = { ...bet, id, createdAt };
    this.bets.set(id, newBet);
    return newBet;
  }

  async updateBet(id: number, cashedOutAt: number, profit: number): Promise<Bet> {
    const bet = this.bets.get(id);
    if (!bet) {
      throw new Error("Bet not found");
    }
    
    const updatedBet = { ...bet, cashedOutAt, profit };
    this.bets.set(id, updatedBet);
    return updatedBet;
  }

  async getBetsByGameId(gameId: number): Promise<Bet[]> {
    return Array.from(this.bets.values()).filter(bet => bet.gameId === gameId);
  }

  async getBetsByUserId(userId: number): Promise<Bet[]> {
    return Array.from(this.bets.values()).filter(bet => bet.userId === userId);
  }

  async getUserStats(userId: number): Promise<UserStats> {
    const bets = await this.getBetsByUserId(userId);
    if (bets.length === 0) {
      return {
        gamesPlayed: 0,
        winRate: 0,
        avgCashout: 0,
        bestCashout: 0,
        totalProfit: 0
      };
    }

    const gamesPlayed = bets.length;
    const wins = bets.filter(bet => bet.profit !== null && bet.profit > 0).length;
    const winRate = wins / gamesPlayed;
    
    const cashedOutBets = bets.filter(bet => bet.cashedOutAt !== null);
    const avgCashout = cashedOutBets.length > 0 
      ? cashedOutBets.reduce((acc, bet) => acc + (bet.cashedOutAt || 0), 0) / cashedOutBets.length 
      : 0;
    
    const bestCashout = cashedOutBets.length > 0 
      ? Math.max(...cashedOutBets.map(bet => bet.cashedOutAt || 0)) 
      : 0;
    
    const totalProfit = bets.reduce((acc, bet) => acc + (bet.profit || 0), 0);

    return {
      gamesPlayed,
      winRate: Math.round(winRate * 100),
      avgCashout,
      bestCashout,
      totalProfit
    };
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const users = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return users[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return users[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(schema.users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserBalance(userId: number, newBalance: number): Promise<User> {
    const [updatedUser] = await db.update(schema.users)
      .set({ balance: newBalance })
      .where(eq(schema.users.id, userId))
      .returning();
    
    if (!updatedUser) {
      throw new Error("User not found");
    }
    
    return updatedUser;
  }

  // Game operations
  async createGame(game: InsertGame): Promise<Game> {
    const [newGame] = await db.insert(schema.games)
      .values(game)
      .returning();
    return newGame;
  }

  async getGameById(id: number): Promise<Game | undefined> {
    const games = await db.select().from(schema.games).where(eq(schema.games.id, id));
    return games[0];
  }

  async getRecentGames(limit: number): Promise<Game[]> {
    return db.select()
      .from(schema.games)
      .orderBy(desc(schema.games.createdAt))
      .limit(limit);
  }

  async getGameStats(count: number): Promise<GameStats> {
    const recentGames = await this.getRecentGames(count);
    if (recentGames.length === 0) {
      return {
        highestMultiplier: 0,
        averageMultiplier: 0,
        distribution: {
          low: 0,
          medium: 0,
          high: 0,
          extreme: 0
        }
      };
    }

    const multipliers = recentGames.map(game => game.crashPoint);
    const highestMultiplier = Math.max(...multipliers);
    const averageMultiplier = multipliers.reduce((a, b) => a + b, 0) / multipliers.length;

    let low = 0, medium = 0, high = 0, extreme = 0;
    for (const mult of multipliers) {
      if (mult < 2) low++;
      else if (mult < 4) medium++;
      else if (mult < 10) high++;
      else extreme++;
    }

    return {
      highestMultiplier,
      averageMultiplier,
      distribution: {
        low: Math.round((low / multipliers.length) * 100),
        medium: Math.round((medium / multipliers.length) * 100),
        high: Math.round((high / multipliers.length) * 100),
        extreme: Math.round((extreme / multipliers.length) * 100)
      }
    };
  }

  // Bet operations
  async createBet(bet: InsertBet): Promise<Bet> {
    const [newBet] = await db.insert(schema.bets)
      .values(bet)
      .returning();
    return newBet;
  }

  async updateBet(id: number, cashedOutAt: number, profit: number): Promise<Bet> {
    const [updatedBet] = await db.update(schema.bets)
      .set({ 
        cashedOutAt,
        profit
      })
      .where(eq(schema.bets.id, id))
      .returning();
    
    if (!updatedBet) {
      throw new Error("Bet not found");
    }
    
    return updatedBet;
  }

  async getBetsByGameId(gameId: number): Promise<Bet[]> {
    return db.select()
      .from(schema.bets)
      .where(eq(schema.bets.gameId, gameId));
  }

  async getBetsByUserId(userId: number): Promise<Bet[]> {
    return db.select()
      .from(schema.bets)
      .where(eq(schema.bets.userId, userId));
  }

  async getUserStats(userId: number): Promise<UserStats> {
    const bets = await this.getBetsByUserId(userId);
    if (bets.length === 0) {
      return {
        gamesPlayed: 0,
        winRate: 0,
        avgCashout: 0,
        bestCashout: 0,
        totalProfit: 0
      };
    }

    const gamesPlayed = bets.length;
    const wins = bets.filter(bet => bet.profit !== null && bet.profit > 0).length;
    const winRate = wins / gamesPlayed;
    
    const cashedOutBets = bets.filter(bet => bet.cashedOutAt !== null);
    const avgCashout = cashedOutBets.length > 0 
      ? cashedOutBets.reduce((acc, bet) => acc + (bet.cashedOutAt || 0), 0) / cashedOutBets.length 
      : 0;
    
    const bestCashout = cashedOutBets.length > 0 
      ? Math.max(...cashedOutBets.map(bet => bet.cashedOutAt || 0)) 
      : 0;
    
    const totalProfit = bets.reduce((acc, bet) => acc + (bet.profit || 0), 0);

    return {
      gamesPlayed,
      winRate: Math.round(winRate * 100),
      avgCashout,
      bestCashout,
      totalProfit
    };
  }
}

// Use database storage instead of in-memory
export const storage = new DatabaseStorage();
