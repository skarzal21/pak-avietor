import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { gameController } from "./game";
import { rng } from "./rng";
import { z } from "zod";
import { insertUserSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Initialize the game controller with the HTTP server (for WebSockets)
  gameController.initialize(httpServer);

  // API routes - prefix all with /api
  
  // Get user by ID
  app.get("/api/users/:id", async (req, res) => {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Don't expose password
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  // Create user
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      
      // Don't expose password
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: err.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  // Login - simplified for demo (no real auth)
  app.post("/api/login", async (req, res) => {
    const loginSchema = z.object({
      username: z.string(),
      password: z.string()
    });

    try {
      const { username, password } = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(username);

      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Don't expose password
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: err.errors });
      }
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Get recent games
  app.get("/api/games/recent", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const games = await storage.getRecentGames(limit);
      res.json(games);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch recent games" });
    }
  });

  // Get game statistics
  app.get("/api/games/stats", async (req, res) => {
    try {
      const count = parseInt(req.query.count as string) || 100;
      const stats = await storage.getGameStats(count);
      res.json(stats);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch game statistics" });
    }
  });

  // Get game by ID
  app.get("/api/games/:id", async (req, res) => {
    try {
      const gameId = parseInt(req.params.id);
      if (isNaN(gameId)) {
        return res.status(400).json({ message: "Invalid game ID" });
      }

      const game = await storage.getGameById(gameId);
      if (!game) {
        return res.status(404).json({ message: "Game not found" });
      }

      res.json(game);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch game" });
    }
  });

  // Get user statistics
  app.get("/api/users/:id/stats", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch user statistics" });
    }
  });

  // Verify game fairness
  app.post("/api/verify", async (req, res) => {
    const verifySchema = z.object({
      seed: z.string(),
      crashPoint: z.number()
    });

    try {
      const { seed, crashPoint } = verifySchema.parse(req.body);
      const isValid = rng.verifyCrashPoint(seed, crashPoint);
      
      // Also verify that the hash matches
      const expectedHash = rng.generateHash(seed);
      
      res.json({
        valid: isValid,
        seed,
        crashPoint,
        hash: expectedHash,
        calculatedCrashPoint: rng.calculateCrashPoint(seed)
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: err.errors });
      }
      res.status(500).json({ message: "Verification failed" });
    }
  });

  return httpServer;
}
