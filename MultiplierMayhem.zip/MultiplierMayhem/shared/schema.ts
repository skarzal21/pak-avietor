import { pgTable, text, serial, integer, boolean, timestamp, real, doublePrecision } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  balance: real("balance").notNull().default(10000),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Game history model
export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  crashPoint: doublePrecision("crash_point").notNull(),
  seed: text("seed").notNull(),
  hash: text("hash").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Bets model
export const bets = pgTable("bets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  gameId: integer("game_id").notNull().references(() => games.id),
  amount: real("amount").notNull(),
  autoCashoutAt: doublePrecision("auto_cashout_at"),
  cashedOutAt: doublePrecision("cashed_out_at"),
  profit: real("profit"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  bets: many(bets),
}));

export const gamesRelations = relations(games, ({ many }) => ({
  bets: many(bets),
}));

export const betsRelations = relations(bets, ({ one }) => ({
  user: one(users, {
    fields: [bets.userId],
    references: [users.id],
  }),
  game: one(games, {
    fields: [bets.gameId],
    references: [games.id],
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  balance: true,
});

export const insertGameSchema = createInsertSchema(games).pick({
  crashPoint: true,
  seed: true,
  hash: true,
});

export const insertBetSchema = createInsertSchema(bets).pick({
  userId: true,
  gameId: true,
  amount: true,
  autoCashoutAt: true,
  cashedOutAt: true,
  profit: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;

export type Bet = typeof bets.$inferSelect;
export type InsertBet = z.infer<typeof insertBetSchema>;

// Game state types
export enum GameState {
  WAITING = "waiting",
  STARTING = "starting",
  ACTIVE = "active",
  CRASHED = "crashed",
}

// WebSocket message types
export type WSMessage = {
  type: string;
  data: any;
};

// Player for live view
export type LivePlayer = {
  id: number;
  username: string;
  bet: number;
  autoCashout?: number;
  cashedOut?: number;
  profit?: number;
};

// Game statistics
export type GameStats = {
  highestMultiplier: number;
  averageMultiplier: number;
  distribution: {
    low: number;    // 1.00× - 1.99×
    medium: number; // 2.00× - 3.99×
    high: number;   // 4.00× - 9.99×
    extreme: number; // 10.00×+
  };
};

// User statistics
export type UserStats = {
  gamesPlayed: number;
  winRate: number;
  avgCashout: number;
  bestCashout: number;
  totalProfit: number;
};
