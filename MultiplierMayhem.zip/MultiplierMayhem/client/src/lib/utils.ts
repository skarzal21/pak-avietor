import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Combines Tailwind CSS classes with proper precedence
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format a number as currency with commas and 2 decimal places
 */
export function formatCurrency(value: number): string {
  return value.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

/**
 * Format a multiplier with appropriate decimal places
 */
export function formatMultiplier(value: number): string {
  return value.toFixed(2) + 'x';
}

/**
 * Get appropriate color for a multiplier
 */
export function getMultiplierColor(value: number): string {
  if (value < 1.2) return "text-crash";
  if (value < 2) return "text-yellow-400";
  if (value < 5) return "text-success";
  return "text-primary";
}

/**
 * Get a shortened version of a hash for display
 */
export function shortenHash(hash: string): string {
  if (!hash) return '';
  return hash.slice(0, 8) + '...' + hash.slice(-8);
}
