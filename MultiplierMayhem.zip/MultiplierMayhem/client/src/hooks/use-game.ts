import { useState, useEffect, useCallback } from "react";
import { useWebSocket } from "./use-websocket";
import { GameState, LivePlayer, GameStats, UserStats } from "@shared/schema";

interface UserData {
  id: number;
  username: string;
  balance: number;
}

export function useGame() {
  const { isConnected, sendMessage, addMessageHandler } = useWebSocket();

  // Game state
  const [gameState, setGameState] = useState<GameState>(GameState.WAITING);
  const [multiplier, setMultiplier] = useState<number>(1.00);
  const [gameId, setGameId] = useState<number | null>(null);
  const [hash, setHash] = useState<string | null>(null);
  const [countdown, setCountdown] = useState<number>(0);
  const [livePlayers, setLivePlayers] = useState<LivePlayer[]>([]);
  
  // User state
  const [userData, setUserData] = useState<UserData | null>(null);
  const [userStats, setUserStats] = useState<UserStats | null>(null);
  const [isBetting, setIsBetting] = useState<boolean>(false);
  const [betAmount, setBetAmount] = useState<number>(100);
  const [autoCashout, setAutoCashout] = useState<number | null>(2.00);

  // Set up message handlers
  useEffect(() => {
    // Game state updates
    const gameStateHandler = addMessageHandler("game_state", (data) => {
      setGameState(data.state);
      setMultiplier(data.multiplier);
      setGameId(data.gameId);
      setHash(data.hash);
      
      // Reset betting state on new game
      if (data.state === GameState.STARTING) {
        setIsBetting(false);
      }
    });
    
    // Multiplier updates
    const multiplierHandler = addMessageHandler("multiplier", (data) => {
      setMultiplier(data.multiplier);
    });
    
    // Countdown updates
    const countdownHandler = addMessageHandler("countdown", (data) => {
      setCountdown(data.countdown);
    });
    
    // Live players updates
    const livePlayersHandler = addMessageHandler("live_players", (data) => {
      setLivePlayers(data.players);
    });
    
    // User data updates
    const userDataHandler = addMessageHandler("user_data", (data) => {
      setUserData(data.user);
      setUserStats(data.stats);
    });
    
    // Cashout notification
    const cashoutHandler = addMessageHandler("cashout", (data) => {
      setIsBetting(false);
    });
    
    return () => {
      gameStateHandler();
      multiplierHandler();
      countdownHandler();
      livePlayersHandler();
      userDataHandler();
      cashoutHandler();
    };
  }, [addMessageHandler]);

  // Authenticate user (simplified for demo)
  const login = useCallback((userId: number, username: string) => {
    if (!isConnected) return false;
    
    sendMessage({
      type: "auth",
      data: { userId, username }
    });
    
    // For demo, immediately set user data
    setUserData({ id: userId, username, balance: 10000 });
    
    return true;
  }, [isConnected, sendMessage]);

  // Place a bet
  const placeBet = useCallback((amount: number, autoCashout: number | null = null) => {
    if (!isConnected || isBetting || gameState !== GameState.STARTING && (gameState !== GameState.ACTIVE || multiplier > 1.1)) {
      return false;
    }
    
    sendMessage({
      type: "place_bet",
      data: { amount, autoCashout }
    });
    
    // Update local state
    setBetAmount(amount);
    setAutoCashout(autoCashout);
    setIsBetting(true);
    
    return true;
  }, [isConnected, sendMessage, isBetting, gameState, multiplier]);

  // Cash out
  const cashout = useCallback(() => {
    if (!isConnected || !isBetting || gameState !== GameState.ACTIVE) {
      return false;
    }
    
    sendMessage({
      type: "cashout",
      data: {}
    });
    
    return true;
  }, [isConnected, sendMessage, isBetting, gameState]);

  // Auto-authenticate on connection
  useEffect(() => {
    if (isConnected && userData) {
      login(userData.id, userData.username);
    }
  }, [isConnected, userData, login]);

  // For demo, auto-login with default user
  useEffect(() => {
    if (isConnected && !userData) {
      login(1, "Player123");
    }
  }, [isConnected, userData, login]);

  return {
    // Game state
    gameState,
    multiplier,
    gameId,
    hash,
    countdown,
    livePlayers,
    
    // User state
    userData,
    userStats,
    isBetting,
    betAmount,
    autoCashout,
    
    // Functions
    login,
    placeBet,
    cashout,
    setBetAmount,
    setAutoCashout
  };
}
