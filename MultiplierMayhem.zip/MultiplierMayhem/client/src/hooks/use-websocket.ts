import { useEffect, useRef, useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { WSMessage } from "@shared/schema";

export function useWebSocket() {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(true);
  const socketRef = useRef<WebSocket | null>(null);
  const { toast } = useToast();
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Message handlers
  const messageHandlersRef = useRef<Record<string, ((data: any) => void)[]>>({});

  // Connect to the WebSocket server
  const connect = useCallback(() => {
    if (socketRef.current?.readyState === WebSocket.OPEN) return;
    
    try {
      setIsConnecting(true);
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      const socket = new WebSocket(wsUrl);
      
      socket.onopen = () => {
        console.log("WebSocket connected");
        setIsConnected(true);
        setIsConnecting(false);
        
        // Clear any reconnect timeout
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
      };
      
      socket.onclose = () => {
        console.log("WebSocket disconnected");
        setIsConnected(false);
        
        // Schedule reconnect
        if (!reconnectTimeoutRef.current) {
          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, 2000);
        }
      };
      
      socket.onerror = (error) => {
        console.error("WebSocket error:", error);
        toast({
          title: "Connection Error",
          description: "Lost connection to the game server. Trying to reconnect...",
          variant: "destructive",
        });
      };
      
      socket.onmessage = (event) => {
        try {
          const message: WSMessage = JSON.parse(event.data);
          const { type, data } = message;
          
          // Call all handlers for this message type
          const handlers = messageHandlersRef.current[type] || [];
          handlers.forEach(handler => handler(data));
          
          // Special handling for error messages
          if (type === "error") {
            toast({
              title: "Error",
              description: data.message,
              variant: "destructive",
            });
          }
        } catch (err) {
          console.error("Failed to parse WebSocket message:", err);
        }
      };
      
      socketRef.current = socket;
    } catch (error) {
      console.error("Failed to connect WebSocket:", error);
      setIsConnecting(false);
      
      // Schedule reconnect
      if (!reconnectTimeoutRef.current) {
        reconnectTimeoutRef.current = setTimeout(() => {
          connect();
        }, 2000);
      }
    }
  }, [toast]);
  
  // Initialize connection on component mount
  useEffect(() => {
    connect();
    
    return () => {
      // Clean up socket on unmount
      if (socketRef.current) {
        socketRef.current.close();
      }
      
      // Clear any reconnect timeout
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [connect]);
  
  // Register a message handler
  const addMessageHandler = useCallback((type: string, handler: (data: any) => void) => {
    messageHandlersRef.current[type] = [
      ...(messageHandlersRef.current[type] || []),
      handler
    ];
    
    // Return a function to unregister the handler
    return () => {
      if (messageHandlersRef.current[type]) {
        messageHandlersRef.current[type] = messageHandlersRef.current[type].filter(h => h !== handler);
      }
    };
  }, []);
  
  // Send a message
  const sendMessage = useCallback((message: WSMessage) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(message));
      return true;
    }
    
    // Automatically try to reconnect and queue the message
    if (!isConnected && !isConnecting) {
      connect();
    }
    
    return false;
  }, [isConnected, isConnecting, connect]);
  
  return {
    isConnected,
    isConnecting,
    sendMessage,
    addMessageHandler
  };
}
