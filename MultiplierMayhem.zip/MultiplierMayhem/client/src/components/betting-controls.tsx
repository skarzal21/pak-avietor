import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { GameState } from "@shared/schema";
import { formatMultiplier } from "@/lib/utils";

interface BettingControlsProps {
  gameState: GameState;
  isBetting: boolean;
  betAmount: number;
  autoCashout: number | null;
  multiplier: number;
  onBetAmountChange: (amount: number) => void;
  onAutoCashoutChange: (value: number | null) => void;
  onPlaceBet: (amount: number, autoCashout: number | null) => void;
  onCashout: () => void;
}

export default function BettingControls({
  gameState,
  isBetting,
  betAmount,
  autoCashout,
  multiplier,
  onBetAmountChange,
  onAutoCashoutChange,
  onPlaceBet,
  onCashout,
}: BettingControlsProps) {
  const [betValue, setBetValue] = useState<string>(betAmount.toString());
  const [cashoutValue, setCashoutValue] = useState<string>(autoCashout?.toString() || "2.00");
  const [autoRounds, setAutoRounds] = useState<number>(10);
  const [winStrategy, setWinStrategy] = useState<string>("reset");
  const [lossStrategy, setLossStrategy] = useState<string>("reset");
  const [isAutoBetting, setIsAutoBetting] = useState<boolean>(false);

  // Update local state when props change
  useEffect(() => {
    setBetValue(betAmount.toString());
  }, [betAmount]);

  useEffect(() => {
    setCashoutValue(autoCashout?.toString() || "2.00");
  }, [autoCashout]);

  // Handle bet amount changes
  const handleBetAmountChange = (value: string) => {
    setBetValue(value);
    const numValue = parseFloat(value);
    if (!isNaN(numValue) && numValue > 0) {
      onBetAmountChange(numValue);
    }
  };

  // Handle auto cashout changes
  const handleCashoutChange = (value: string) => {
    setCashoutValue(value);
    const numValue = parseFloat(value);
    if (!isNaN(numValue) && numValue >= 1) {
      onAutoCashoutChange(numValue);
    } else if (value === "") {
      onAutoCashoutChange(null);
    }
  };

  // Quick bet amount changes
  const halfBet = () => {
    const half = betAmount / 2;
    setBetValue(half.toString());
    onBetAmountChange(half);
  };

  const doubleBet = () => {
    const double = betAmount * 2;
    setBetValue(double.toString());
    onBetAmountChange(double);
  };

  // Place bet
  const placeBet = () => {
    const amount = parseFloat(betValue);
    const cashout = parseFloat(cashoutValue);
    
    if (!isNaN(amount) && amount > 0) {
      onPlaceBet(
        amount, 
        !isNaN(cashout) && cashout >= 1 ? cashout : null
      );
    }
  };

  // Cash out
  const cashout = () => {
    onCashout();
  };

  // Toggle auto betting
  const toggleAutoBetting = () => {
    setIsAutoBetting(!isAutoBetting);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
      {/* Manual Betting */}
      <Card>
        <CardContent className="p-4">
          <h3 className="font-semibold text-sm mb-4 flex items-center">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-4 h-4 mr-2 text-secondary"
            >
              <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
            </svg>
            Manual Bet
          </h3>
          
          <div className="space-y-4">
            {/* Bet amount */}
            <div>
              <Label className="text-xs text-muted-foreground mb-1">Bet Amount</Label>
              <div className="relative">
                <Input
                  type="text"
                  value={betValue}
                  onChange={(e) => handleBetAmountChange(e.target.value)}
                  className="font-mono text-foreground"
                  disabled={isBetting}
                />
                <div className="absolute right-0 top-0 h-full flex">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="px-2 text-xs text-muted-foreground hover:text-secondary"
                    onClick={halfBet}
                    disabled={isBetting}
                  >
                    1/2
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="px-2 text-xs text-muted-foreground hover:text-secondary"
                    onClick={doubleBet}
                    disabled={isBetting}
                  >
                    2x
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Auto cashout */}
            <div>
              <Label className="text-xs text-muted-foreground mb-1">Auto Cashout at</Label>
              <div className="relative">
                <Input
                  type="text"
                  value={cashoutValue}
                  onChange={(e) => handleCashoutChange(e.target.value)}
                  className="font-mono text-foreground"
                  disabled={isBetting}
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">×</div>
              </div>
            </div>
            
            {/* Action buttons */}
            <div className="pt-2">
              {!isBetting ? (
                <Button
                  className="w-full bg-primary hover:bg-primary/90 py-6"
                  onClick={placeBet}
                  disabled={gameState !== GameState.STARTING && !(gameState === GameState.ACTIVE && multiplier <= 1.1)}
                >
                  Place Bet
                </Button>
              ) : (
                <Button
                  className="w-full bg-green-600 hover:bg-green-500 py-6"
                  onClick={cashout}
                  disabled={gameState !== GameState.ACTIVE}
                >
                  Cashout <span className="font-mono ml-1">{formatMultiplier(multiplier)}</span>
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Auto Betting */}
      <Card>
        <CardContent className="p-4">
          <h3 className="font-semibold text-sm mb-4 flex items-center">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-4 h-4 mr-2 text-secondary"
            >
              <path d="M12 8V4H8" />
              <rect width="16" height="12" x="4" y="8" rx="2" />
              <path d="M2 14h2" />
              <path d="M20 14h2" />
              <path d="M15 13v2" />
              <path d="M9 13v2" />
            </svg>
            Auto Bet
          </h3>
          
          <div className="space-y-4">
            {/* Number of rounds */}
            <div>
              <Label className="text-xs text-muted-foreground mb-1">Number of Rounds</Label>
              <Input
                type="number"
                value={autoRounds}
                min={1}
                max={100}
                onChange={(e) => setAutoRounds(parseInt(e.target.value))}
                className="font-mono text-foreground"
                disabled={isAutoBetting}
              />
            </div>
            
            {/* On Win */}
            <div>
              <Label className="text-xs text-muted-foreground mb-1">On Win</Label>
              <Select
                value={winStrategy}
                onValueChange={setWinStrategy}
                disabled={isAutoBetting}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select strategy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="reset">Reset to base</SelectItem>
                  <SelectItem value="increase50">Increase by 50%</SelectItem>
                  <SelectItem value="increase100">Increase by 100%</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* On Loss */}
            <div>
              <Label className="text-xs text-muted-foreground mb-1">On Loss</Label>
              <Select
                value={lossStrategy}
                onValueChange={setLossStrategy}
                disabled={isAutoBetting}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select strategy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="reset">Reset to base</SelectItem>
                  <SelectItem value="martingale">Martingale (2x)</SelectItem>
                  <SelectItem value="fibonacci">Fibonacci</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Auto betting button */}
            <div className="pt-2">
              <Button
                variant="outline"
                className={`w-full border-primary text-primary hover:bg-primary/10 py-6 ${
                  isAutoBetting ? "bg-primary/10" : ""
                }`}
                onClick={toggleAutoBetting}
                disabled={gameState === GameState.CRASHED || isBetting}
              >
                {isAutoBetting ? "Stop Auto Bet" : "Start Auto Bet"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
