import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface ChatMessage {
  id: number;
  username: string;
  message: string;
  type: "system" | "user" | "win" | "loss";
}

export default function GameChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  
  // Mock chat messages
  const messages: ChatMessage[] = [
    { id: 1, username: "System", message: "Welcome to the game! Good luck!", type: "system" },
    { id: 2, username: "RocketMan", message: "Just won 380! This game is awesome", type: "win" },
    { id: 3, username: "LuckyGamer", message: "Anyone have tips for winning?", type: "user" },
    { id: 4, username: "BigBettor", message: "Nooo! Lost at 1.24x :(", type: "loss" },
  ];
  
  const getUsernameColor = (type: string) => {
    switch (type) {
      case "system": return "text-primary";
      case "win": return "text-success";
      case "loss": return "text-destructive";
      default: return "text-foreground";
    }
  };
  
  const sendMessage = () => {
    if (message.trim()) {
      // In a real app, would send to backend
      console.log("Sending message:", message);
      setMessage("");
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  };

  return (
    <Card className="shadow-lg overflow-hidden">
      <CardHeader 
        className="p-4 border-b border-border flex justify-between items-center cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <CardTitle className="text-base font-semibold">Chat</CardTitle>
        <svg
          xmlns="http://www.w3.org/2000/svg" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          className={cn("w-5 h-5 transition-transform", isOpen ? "rotate-180" : "")}
        >
          <path d="m6 9 6 6 6-6" />
        </svg>
      </CardHeader>
      
      {isOpen && (
        <>
          <ScrollArea className="h-[200px]">
            <CardContent className="p-3 space-y-2 bg-muted">
              {messages.map((msg) => (
                <div key={msg.id} className="flex space-x-2">
                  <div className={`font-medium ${getUsernameColor(msg.type)}`}>
                    {msg.username}:
                  </div>
                  <div>{msg.message}</div>
                </div>
              ))}
            </CardContent>
          </ScrollArea>
          
          <div className="p-2 border-t border-border">
            <div className="flex">
              <Input
                type="text"
                placeholder="Type a message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-grow rounded-r-none"
              />
              <Button 
                className="bg-primary hover:bg-primary/90 rounded-l-none px-4"
                onClick={sendMessage}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-4 h-4"
                >
                  <path d="m3 10 5 2L8 18l4-6 8 2-10-8Z" />
                </svg>
              </Button>
            </div>
          </div>
        </>
      )}
    </Card>
  );
}
