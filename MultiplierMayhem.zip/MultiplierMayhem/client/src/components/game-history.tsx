import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Game } from "@shared/schema";
import { formatMultiplier, formatCurrency } from "@/lib/utils";
import { motion } from "framer-motion";

export default function GameHistory() {
  const [recentBubbles, setRecentBubbles] = useState<{ multiplier: number; color: string }[]>([]);
  
  // Fetch recent games
  const { data: recentGames } = useQuery({
    queryKey: ['/api/games/recent'],
    refetchInterval: 5000, // Refetch every 5 seconds
  });

  // Update history bubbles when games data changes
  useEffect(() => {
    if (recentGames && Array.isArray(recentGames)) {
      const bubbles = recentGames.slice(0, 8).map((game: Game) => ({
        multiplier: game.crashPoint,
        color: game.crashPoint < 2 ? '#FF5252' : '#00C853'
      }));
      setRecentBubbles(bubbles);
    }
  }, [recentGames]);

  // Mock data for development
  const mockGames = [
    { id: 48290, multiplier: 1.24, players: 132, bet: 200, profit: -200 },
    { id: 48289, multiplier: 3.28, players: 145, bet: 100, profit: 152 },
    { id: 48288, multiplier: 1.02, players: 118, bet: null, profit: null }
  ];

  return (
    <Card className="shadow-lg overflow-hidden">
      <CardHeader className="p-4 border-b border-border flex flex-row justify-between items-center">
        <CardTitle className="text-base font-semibold">Game History</CardTitle>
        <div className="flex space-x-1">
          {recentBubbles.map((game, index) => (
            <div
              key={index}
              className="history-item w-7 h-7 flex items-center justify-center text-[10px] font-semibold"
            >
              {game.multiplier.toFixed(1)}
            </div>
          ))}
        </div>
      </CardHeader>
      
      <CardContent className="p-4">
        {/* Game Chart */}
        <div className="h-[120px] mb-4 relative">
          <svg viewBox="0 0 400 120" className="w-full h-full">
            <defs>
              <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ff3e4d" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#ff8f70" stopOpacity="0.1" />
              </linearGradient>
              <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ff3e4d" />
                <stop offset="100%" stopColor="#ff8f70" />
              </linearGradient>
            </defs>
            
            {/* Background grid lines */}
            <line x1="0" y1="30" x2="400" y2="30" stroke="#333333" strokeWidth="1" strokeDasharray="4" />
            <line x1="0" y1="60" x2="400" y2="60" stroke="#333333" strokeWidth="1" strokeDasharray="4" />
            <line x1="0" y1="90" x2="400" y2="90" stroke="#333333" strokeWidth="1" strokeDasharray="4" />
            
            {/* Y-axis labels */}
            <text x="5" y="30" fill="#AAAAAA" fontSize="10">5.0×</text>
            <text x="5" y="60" fill="#AAAAAA" fontSize="10">3.0×</text>
            <text x="5" y="90" fill="#AAAAAA" fontSize="10">1.5×</text>
            
            {/* Chart line - this would be dynamic in a real implementation */}
            <motion.path 
              d="M 40 120 L 70 90 L 100 60 L 130 40 L 160 30 L 190 35 L 220 50 L 250 70 L 280 50 L 310 20 L 340 10 L 370 120" 
              stroke="url(#lineGradient)"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 2 }}
            />
            
            {/* Area under the line */}
            <path 
              d="M 40 120 L 70 90 L 100 60 L 130 40 L 160 30 L 190 35 L 220 50 L 250 70 L 280 50 L 310 20 L 340 10 L 370 120 L 40 120" 
              fill="url(#chartGradient)"
              opacity="0.5"
            />
            
            {/* Crash points */}
            <circle cx="370" cy="120" r="5" fill="hsl(var(--destructive))" />
            
            {/* Cashout markers */}
            <circle cx="160" cy="30" r="4" fill="hsl(var(--success))" />
            <circle cx="220" cy="50" r="4" fill="hsl(var(--success))" />
            <circle cx="310" cy="20" r="4" fill="hsl(var(--success))" />
          </svg>
        </div>
        
        {/* History table */}
        <div className="rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="py-2 px-3 text-left text-xs font-semibold text-muted-foreground">Round</th>
                <th className="py-2 px-3 text-left text-xs font-semibold text-muted-foreground">Multiplier</th>
                <th className="py-2 px-3 text-right text-xs font-semibold text-muted-foreground hidden sm:table-cell">Players</th>
                <th className="py-2 px-3 text-right text-xs font-semibold text-muted-foreground">My Bet</th>
                <th className="py-2 px-3 text-right text-xs font-semibold text-muted-foreground">Profit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {mockGames.map((game) => (
                <tr key={game.id} className="hover:bg-muted/50 cursor-pointer">
                  <td className="py-3 px-3 font-mono text-muted-foreground">{game.id}</td>
                  <td className="py-3 px-3">
                    <span className={`inline-flex items-center font-mono font-semibold ${
                      game.multiplier < 2 ? 'text-destructive' : 'text-success'
                    }`}>
                      {formatMultiplier(game.multiplier)}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right text-muted-foreground hidden sm:table-cell">{game.players}</td>
                  <td className="py-3 px-3 text-right font-mono">
                    {game.bet !== null ? formatCurrency(game.bet) : '-'}
                  </td>
                  <td className={`py-3 px-3 text-right font-mono ${
                    game.profit === null ? '' : game.profit > 0 ? 'text-success' : 'text-destructive'
                  }`}>
                    {game.profit !== null ? (game.profit > 0 ? '+' : '') + formatCurrency(game.profit) : '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
