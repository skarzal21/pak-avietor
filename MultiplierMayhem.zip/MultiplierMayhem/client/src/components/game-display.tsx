import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn, formatMultiplier, shortenHash } from "@/lib/utils";
import { GameState } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";

interface GameDisplayProps {
  gameState: GameState;
  multiplier: number;
  hash: string | null;
  activePlayers: number;
  gameId: number;
}

export default function GameDisplay({ 
  gameState, 
  multiplier, 
  hash, 
  activePlayers, 
  gameId 
}: GameDisplayProps) {
  const [prevMultiplier, setPrevMultiplier] = useState(1.00);
  const containerRef = useRef<HTMLDivElement>(null);
  const planeRef = useRef<HTMLDivElement>(null);
  
  // Track previous multiplier for animations
  useEffect(() => {
    if (gameState === GameState.ACTIVE) {
      setPrevMultiplier(multiplier);
    } else if (gameState === GameState.STARTING) {
      setPrevMultiplier(1.00);
    }
  }, [multiplier, gameState]);
  
  // Animate the plane based on multiplier
  useEffect(() => {
    if (gameState === GameState.ACTIVE && planeRef.current && containerRef.current) {
      const container = containerRef.current;
      const plane = planeRef.current;
      
      // Calculate position based on multiplier (non-linear)
      const xPercent = Math.min(95, (multiplier - 1) * 30);
      const yPercent = Math.min(95, (multiplier - 1) * 40);
      
      // Position the plane
      const x = (container.clientWidth * xPercent) / 100;
      const y = (container.clientHeight * yPercent) / 100;
      
      plane.style.transform = `translate(${x}px, -${y}px) rotate(-45deg)`;
    }
  }, [multiplier, gameState]);

  return (
    <Card className="relative bg-card shadow-lg overflow-hidden mb-6 border-none">
      {/* Game area */}
      <div 
        ref={containerRef}
        className="w-full h-[50vh] min-h-[320px] p-4 flex items-center justify-center relative game-background"
      >
        {/* Background grid lines */}
        <div className="absolute inset-0 grid grid-cols-12 grid-rows-6 opacity-10 pointer-events-none">
          {Array(12).fill(0).map((_, i) => (
            <div key={`col-${i}`} className="border-r border-white h-full"></div>
          ))}
          {Array(6).fill(0).map((_, i) => (
            <div key={`row-${i}`} className="border-b border-white w-full col-span-12"></div>
          ))}
        </div>
        
        {/* Multiplier Display */}
        <div className="relative z-10 pointer-events-none">
          <AnimatePresence mode="wait">
            {/* Waiting State */}
            {gameState === GameState.WAITING && (
              <motion.div 
                key="waiting"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="text-center"
              >
                <motion.div 
                  animate={{ y: [0, -10, 0] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="inline-block"
                >
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="w-16 h-16 text-secondary mb-4"
                  >
                    <path d="M5 18H3c-.6 0-1-.4-1-1V7c0-.6.4-1 1-1h10c.6 0 1 .4 1 1v11" />
                    <path d="M14 9h4l4 4v4c0 .6-.4 1-1 1h-7c-.6 0-1-.4-1-1v-7c0-.6.4-1 1-1z" />
                    <circle cx="8" cy="18" r="2" />
                    <circle cx="17" cy="18" r="2" />
                  </svg>
                  <div className="text-muted-foreground">Waiting for next round...</div>
                </motion.div>
              </motion.div>
            )}
            
            {/* Active Game */}
            {gameState === GameState.ACTIVE && (
              <motion.div 
                key="active"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, y: -20 }}
                className="text-center"
              >
                <motion.div 
                  key={Math.floor(multiplier * 100)}
                  initial={{ scale: 0.9 }}
                  animate={{ scale: 1 }}
                  className={cn(
                    "font-mono font-bold text-7xl md:text-8xl lg:text-9xl transition-colors duration-100 multiplier-display",
                    multiplier >= 10 && "high-multiplier"
                  )}
                >
                  {formatMultiplier(multiplier)}
                </motion.div>
                <div className="mt-2 text-muted-foreground text-sm">
                  Multiplier increasing!
                </div>
              </motion.div>
            )}
            
            {/* Crashed State */}
            {gameState === GameState.CRASHED && (
              <motion.div 
                key="crashed"
                initial={{ opacity: 0, scale: 1.2 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="text-center"
              >
                <motion.div 
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ repeat: 3, duration: 0.3 }}
                  className="font-mono font-bold text-7xl md:text-8xl lg:text-9xl multiplier-display high-multiplier"
                  style={{ 
                    background: 'linear-gradient(to right, #ff3e4d, #ff0000)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    textShadow: '0 0 15px rgba(255, 0, 0, 0.7)'
                  }}
                >
                  {formatMultiplier(multiplier)}
                </motion.div>
                <div className="mt-2 text-destructive text-sm">
                  CRASHED!
                </div>
              </motion.div>
            )}
            
            {/* Starting State */}
            {gameState === GameState.STARTING && (
              <motion.div 
                key="starting"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="text-center"
              >
                <motion.div 
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ repeat: Infinity, duration: 1 }}
                  className="inline-block"
                >
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="w-16 h-16 text-secondary mb-4"
                  >
                    <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                  </svg>
                  <div className="text-muted-foreground">Get ready for takeoff!</div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        {/* Plane */}
        {gameState === GameState.ACTIVE && (
          <div 
            ref={planeRef}
            className="absolute left-0 bottom-0"
            style={{ transform: "translate(0, 0) rotate(-45deg)" }}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-10 h-10 text-secondary"
            >
              <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z" />
            </svg>
          </div>
        )}
        
        {/* Crash effect */}
        <AnimatePresence>
          {gameState === GameState.CRASHED && (
            <motion.div 
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 4, opacity: [0, 0.7, 0] }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="absolute w-16 h-16 rounded-full bg-destructive"
              style={{ 
                left: `${Math.min(95, (multiplier - 1) * 30)}%`, 
                bottom: `${Math.min(95, (multiplier - 1) * 40)}%` 
              }}
            />
          )}
        </AnimatePresence>
      </div>
      
      {/* Game Info Bar */}
      <div className="bg-muted border-t border-border p-3 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          {/* Provably fair info */}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center text-xs text-muted-foreground cursor-pointer">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="w-3 h-3 mr-1"
                  >
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                  </svg>
                  <span>Provably Fair</span>
                </div>
              </TooltipTrigger>
              <TooltipContent side="top" className="w-64 p-3">
                <div className="font-semibold mb-1">Round Hash:</div>
                <div className="font-mono text-muted-foreground break-all text-[10px]">
                  {hash || 'N/A'}
                </div>
                <div className="mt-2">
                  <a href="#" className="text-secondary hover:underline text-xs">Verify Fairness</a>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          {/* Active players */}
          <div className="text-xs">
            <span className="text-muted-foreground">Players:</span>
            <span className="text-foreground font-semibold ml-1">{activePlayers}</span>
          </div>
        </div>
        
        <div>
          <div className="flex items-center text-xs">
            <span className="text-muted-foreground mr-1">Round:</span>
            <span className="font-mono">{gameId}</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
