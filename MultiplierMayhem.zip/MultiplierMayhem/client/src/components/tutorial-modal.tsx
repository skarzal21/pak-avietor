import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface TutorialModalProps {
  onClose: () => void;
}

export default function TutorialModal({ onClose }: TutorialModalProps) {
  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">How to Play</DialogTitle>
          <DialogDescription>Learn how to play the Multiplier betting game</DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 my-2">
          <div className="space-y-2">
            <h4 className="font-medium text-lg flex items-center">
              <div className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 text-sm">1</div>
              Place Your Bet
            </h4>
            <p className="text-muted-foreground">Enter your bet amount and optional auto-cashout multiplier.</p>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-medium text-lg flex items-center">
              <div className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 text-sm">2</div>
              Watch The Multiplier
            </h4>
            <p className="text-muted-foreground">The multiplier starts at 1.00× and increases. The longer it goes, the higher your potential winnings!</p>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-medium text-lg flex items-center">
              <div className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 text-sm">3</div>
              Cash Out In Time
            </h4>
            <p className="text-muted-foreground">Cash out before the multiplier crashes to win your bet × the current multiplier. If you wait too long, you lose!</p>
          </div>
          
          <div className="mt-6 text-xs text-muted-foreground">
            <p>All outcomes are determined by a provably fair algorithm that you can verify. Learn more about how it works in the Provably Fair section.</p>
          </div>
        </div>
        
        <DialogFooter>
          <Button onClick={onClose} className="w-full sm:w-auto">
            Got It
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
