import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { GameStats, UserStats } from "@shared/schema";
import { formatMultiplier, formatCurrency } from "@/lib/utils";

interface GameStatisticsProps {
  userId?: number;
}

export default function GameStatistics({ userId }: GameStatisticsProps) {
  // Fetch game statistics
  const { data: gameStats } = useQuery<GameStats>({
    queryKey: ['/api/games/stats'],
    refetchInterval: 10000, // Refetch every 10 seconds
  });

  // Fetch user statistics if userId is provided
  const { data: userStats } = useQuery<UserStats>({
    queryKey: ['/api/users', userId, 'stats'],
    enabled: !!userId,
    refetchInterval: 5000,
  });

  // Default stats if data is not yet available
  const stats = gameStats || {
    highestMultiplier: 32.41,
    averageMultiplier: 2.14,
    distribution: {
      low: 63,
      medium: 25,
      high: 9,
      extreme: 3
    }
  };

  // Default user stats if data is not yet available
  const userStatsData = userStats || {
    gamesPlayed: 42,
    winRate: 64,
    avgCashout: 1.85,
    bestCashout: 7.65,
    totalProfit: 1452.25
  };

  return (
    <Card className="shadow-lg overflow-hidden">
      <CardHeader className="p-4 border-b border-border">
        <CardTitle className="text-base font-semibold">Game Statistics</CardTitle>
      </CardHeader>
      
      <CardContent className="p-4 space-y-4">
        {/* Stat cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-muted p-3 rounded-lg">
            <div className="text-xs text-muted-foreground mb-1">Highest Mult</div>
            <div className="font-mono font-bold text-xl text-secondary">
              {formatMultiplier(stats.highestMultiplier)}
            </div>
          </div>
          <div className="bg-muted p-3 rounded-lg">
            <div className="text-xs text-muted-foreground mb-1">Avg Mult</div>
            <div className="font-mono font-bold text-xl">
              {formatMultiplier(stats.averageMultiplier)}
            </div>
          </div>
        </div>
        
        {/* Distribution bars */}
        <div>
          <div className="flex justify-between text-xs text-muted-foreground mb-1">
            <span>Multiplier Distribution</span>
            <span>Last 100 games</span>
          </div>
          
          <div className="space-y-2 mt-2">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>1.00× - 1.99×</span>
                <span className="font-mono">{stats.distribution.low}%</span>
              </div>
              <Progress value={stats.distribution.low} className="h-2">
                <div className="h-full bg-destructive" style={{ width: `${stats.distribution.low}%` }} />
              </Progress>
            </div>
            
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>2.00× - 3.99×</span>
                <span className="font-mono">{stats.distribution.medium}%</span>
              </div>
              <Progress value={stats.distribution.medium} className="h-2">
                <div className="h-full bg-secondary" style={{ width: `${stats.distribution.medium}%` }} />
              </Progress>
            </div>
            
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>4.00× - 9.99×</span>
                <span className="font-mono">{stats.distribution.high}%</span>
              </div>
              <Progress value={stats.distribution.high} className="h-2">
                <div className="h-full bg-primary" style={{ width: `${stats.distribution.high}%` }} />
              </Progress>
            </div>
            
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>10.00×+</span>
                <span className="font-mono">{stats.distribution.extreme}%</span>
              </div>
              <Progress value={stats.distribution.extreme} className="h-2">
                <div className="h-full bg-success" style={{ width: `${stats.distribution.extreme}%` }} />
              </Progress>
            </div>
          </div>
        </div>
        
        {/* My Stats */}
        <div>
          <div className="text-xs text-muted-foreground mb-2">My Statistics</div>
          
          <div className="grid grid-cols-2 gap-y-3 text-sm">
            <div>
              <span className="text-muted-foreground">Games Played:</span>
            </div>
            <div className="text-right font-mono">
              {userStatsData.gamesPlayed}
            </div>
            
            <div>
              <span className="text-muted-foreground">Win Rate:</span>
            </div>
            <div className="text-right font-mono">
              {userStatsData.winRate}%
            </div>
            
            <div>
              <span className="text-muted-foreground">Avg Cashout:</span>
            </div>
            <div className="text-right font-mono">
              {formatMultiplier(userStatsData.avgCashout)}
            </div>
            
            <div>
              <span className="text-muted-foreground">Best Cashout:</span>
            </div>
            <div className="text-right font-mono">
              {formatMultiplier(userStatsData.bestCashout)}
            </div>
            
            <div>
              <span className="text-muted-foreground">Total Profit:</span>
            </div>
            <div className={`text-right font-mono ${
              userStatsData.totalProfit > 0 ? 'text-success' : 'text-destructive'
            }`}>
              {userStatsData.totalProfit > 0 ? '+' : ''}
              {formatCurrency(userStatsData.totalProfit)}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
