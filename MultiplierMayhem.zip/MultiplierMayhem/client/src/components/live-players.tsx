import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { LivePlayer } from "@shared/schema";
import { formatCurrency, formatMultiplier } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

interface LivePlayersProps {
  players: LivePlayer[];
}

export default function LivePlayers({ players }: LivePlayersProps) {
  const [sortedPlayers, setSortedPlayers] = useState<LivePlayer[]>([]);

  // Sort players by status (active first) and bet amount
  useEffect(() => {
    const sorted = [...players].sort((a, b) => {
      // Sort by status first (cashed out, then active, then busted)
      if (a.cashedOut && !b.cashedOut) return -1;
      if (!a.cashedOut && b.cashedOut) return 1;
      
      // Then by bet amount (highest first)
      return b.bet - a.bet;
    });
    
    setSortedPlayers(sorted);
  }, [players]);

  // Get status indicator color
  const getStatusColor = (player: LivePlayer) => {
    if (player.cashedOut) return "bg-success";
    if (player.profit !== undefined && player.profit < 0) return "bg-destructive";
    return "bg-primary";
  };

  // Get multiplier display
  const getMultiplierDisplay = (player: LivePlayer) => {
    if (player.cashedOut) return (
      <span className="text-success">{formatMultiplier(player.cashedOut)}</span>
    );
    if (player.profit !== undefined && player.profit < 0) return (
      <span className="text-destructive">lost</span>
    );
    return <span className="text-muted-foreground">in</span>;
  };

  return (
    <Card className="shadow-lg overflow-hidden">
      <CardHeader className="p-4 border-b border-border">
        <CardTitle className="text-base font-semibold">Live Players</CardTitle>
      </CardHeader>
      
      <ScrollArea className="max-h-[300px]">
        <table className="w-full text-sm">
          <thead className="bg-muted">
            <tr>
              <th className="py-2 px-3 text-left text-xs font-semibold text-muted-foreground">Player</th>
              <th className="py-2 px-3 text-right text-xs font-semibold text-muted-foreground">Bet</th>
              <th className="py-2 px-3 text-right text-xs font-semibold text-muted-foreground">Mult</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            <AnimatePresence>
              {sortedPlayers.map((player) => (
                <motion.tr
                  key={player.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <td className="py-2 px-3 font-medium">
                    <div className="flex items-center">
                      <div className={`w-2 h-2 ${getStatusColor(player)} rounded-full mr-2`}></div>
                      <span className="truncate">{player.username}</span>
                    </div>
                  </td>
                  <td className="py-2 px-3 text-right font-mono text-muted-foreground">
                    {formatCurrency(player.bet)}
                  </td>
                  <td className="py-2 px-3 text-right font-mono">
                    {getMultiplierDisplay(player)}
                  </td>
                </motion.tr>
              ))}
              
              {sortedPlayers.length === 0 && (
                <tr>
                  <td colSpan={3} className="py-4 text-center text-muted-foreground">
                    No active players
                  </td>
                </tr>
              )}
            </AnimatePresence>
          </tbody>
        </table>
      </ScrollArea>
    </Card>
  );
}
