import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useGame } from "@/hooks/use-game";
import { GameState } from "@shared/schema";

// Components
import GameDisplay from "@/components/game-display";
import BettingControls from "@/components/betting-controls";
import GameHistory from "@/components/game-history";
import LivePlayers from "@/components/live-players";
import GameStatistics from "@/components/game-statistics";
import GameChat from "@/components/game-chat";
import TutorialModal from "@/components/tutorial-modal";

export default function Home() {
  const { toast } = useToast();
  const [showMobileNav, setShowMobileNav] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const game = useGame();

  // Check if user has seen tutorial before
  useEffect(() => {
    const hasSeenTutorial = localStorage.getItem("multiplier_game_tutorial");
    if (!hasSeenTutorial) {
      setShowTutorial(true);
    }
  }, []);

  // Handle tutorial completion
  const handleTutorialClose = () => {
    localStorage.setItem("multiplier_game_tutorial", "true");
    setShowTutorial(false);
  };

  return (
    <div className="bg-background text-foreground font-sans overflow-x-hidden min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-background-dark shadow-md py-4 px-4 md:px-8 flex justify-between items-center border-b border-border">
        <div className="flex items-center">
          <div className="text-primary font-bold text-xl md:text-2xl flex items-center">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-6 h-6 mr-2 text-secondary"
            >
              <path d="M2 22h20" />
              <path d="M6.36 17.4 4 17l-2-4 1.1-2.2c.3-.6.9-1 1.7-1H16c.3 0 .5.1.7.3L22 15" />
              <path d="m4 17 3.3-12c.3-1 1.2-1.7 2.3-1.7H16c.3 0 .5.1.7.3L22 9" />
              <path d="M18 22V9" />
              <path d="M18 4v2" />
              <path d="m14 22-4-16" />
            </svg>
            <span>MULTIPLIER</span>
          </div>
        </div>
        
        <nav className="hidden md:flex items-center space-x-6 text-sm">
          <a href="#" className="hover:text-secondary transition-colors duration-200 font-medium">Game</a>
          <a href="#" className="hover:text-secondary transition-colors duration-200">Statistics</a>
          <a href="#" className="hover:text-secondary transition-colors duration-200" onClick={(e) => {
            e.preventDefault();
            setShowTutorial(true);
          }}>How to Play</a>
          <a href="#" className="hover:text-secondary transition-colors duration-200">Provably Fair</a>
        </nav>
        
        <div className="flex items-center space-x-4">
          {/* Balance */}
          <div className="text-muted-foreground hidden md:flex flex-col items-end">
            <span className="text-xs text-muted-foreground">Balance</span>
            <span className="font-mono font-semibold">
              {game.userData ? game.userData.balance.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
              }) : '0.00'}
            </span>
          </div>
          
          {/* User */}
          <div className="flex items-center space-x-2">
            <span className="hidden md:inline">{game.userData?.username || 'Guest'}</span>
            <div className="w-8 h-8 bg-primary-dark rounded-full flex items-center justify-center">
              <span className="text-sm font-medium">{game.userData?.username?.[0] || 'G'}</span>
            </div>
          </div>
          
          {/* Mobile menu button */}
          <button className="md:hidden text-xl" onClick={() => setShowMobileNav(!showMobileNav)}>
            <svg
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-6 h-6"
            >
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
          </button>
        </div>
      </header>
      
      {/* Mobile Navigation */}
      <div 
        className={`md:hidden fixed bottom-0 left-0 w-full bg-background border-t border-border transform ${
          showMobileNav ? 'translate-y-0' : 'translate-y-full'
        } transition-transform duration-300 z-50 rounded-t-xl shadow-lg`}
      >
        <div className="flex justify-center pt-2 pb-1">
          <div className="w-12 h-1 bg-muted rounded-full"></div>
        </div>
        <div className="p-4 space-y-3">
          <div className="flex justify-between items-center p-2">
            <span className="text-sm text-muted-foreground">Balance</span>
            <span className="font-mono font-semibold">
              {game.userData ? game.userData.balance.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
              }) : '0.00'}
            </span>
          </div>
          <div className="border-t border-border my-2"></div>
          <a href="#" className="block p-3 hover:bg-muted rounded-lg">
            <div className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-5 h-5 mr-3"
              >
                <rect width="20" height="14" x="2" y="6" rx="2" />
                <path d="M6 12h.01M4 16h16M10 12h.01M14 12h.01M18 12h.01" />
              </svg>
              <span>Game</span>
            </div>
          </a>
          <a href="#" className="block p-3 hover:bg-muted rounded-lg">
            <div className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-5 h-5 mr-3"
              >
                <line x1="12" x2="12" y1="20" y2="10" />
                <line x1="18" x2="18" y1="20" y2="4" />
                <line x1="6" x2="6" y1="20" y2="16" />
              </svg>
              <span>Statistics</span>
            </div>
          </a>
          <a href="#" className="block p-3 hover:bg-muted rounded-lg" onClick={(e) => {
            e.preventDefault();
            setShowTutorial(true);
            setShowMobileNav(false);
          }}>
            <div className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-5 h-5 mr-3"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                <path d="M12 17h.01" />
              </svg>
              <span>How to Play</span>
            </div>
          </a>
          <a href="#" className="block p-3 hover:bg-muted rounded-lg">
            <div className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-5 h-5 mr-3"
              >
                <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
              <span>Provably Fair</span>
            </div>
          </a>
        </div>
      </div>
      
      {/* Main Content */}
      <main className="flex-grow flex flex-col lg:flex-row">
        {/* Game and Betting Section */}
        <div className="flex-grow p-4 md:p-6 lg:w-3/4">
          {/* Game Status */}
          <div className="text-center mb-4">
            <div className="inline-block bg-card px-4 py-2 rounded-full text-sm">
              {game.gameState === GameState.WAITING && (
                <span className="font-medium text-secondary">WAITING FOR NEXT ROUND</span>
              )}
              {game.gameState === GameState.STARTING && (
                <span className="font-medium text-secondary">STARTING IN <span>{game.countdown}s</span></span>
              )}
              {game.gameState === GameState.ACTIVE && (
                <span className="font-medium text-secondary">GAME IN PROGRESS</span>
              )}
              {game.gameState === GameState.CRASHED && (
                <span className="font-medium text-destructive">CRASHED!</span>
              )}
            </div>
          </div>
          
          {/* Game Display */}
          <GameDisplay 
            gameState={game.gameState}
            multiplier={game.multiplier}
            hash={game.hash}
            activePlayers={game.livePlayers.length}
            gameId={game.gameId || 0}
          />
          
          {/* Betting Controls */}
          <BettingControls 
            gameState={game.gameState}
            isBetting={game.isBetting}
            betAmount={game.betAmount}
            autoCashout={game.autoCashout}
            multiplier={game.multiplier}
            onBetAmountChange={(amount) => game.setBetAmount(amount)}
            onAutoCashoutChange={(value) => game.setAutoCashout(value)}
            onPlaceBet={(amount, autoCashout) => {
              if (game.placeBet(amount, autoCashout)) {
                toast({
                  title: "Bet Placed",
                  description: `Bet of ${amount.toFixed(2)} placed. Good luck!`,
                });
              } else {
                toast({
                  title: "Couldn't place bet",
                  description: "You can only place bets during the starting phase.",
                  variant: "destructive",
                });
              }
            }}
            onCashout={() => {
              if (game.cashout()) {
                toast({
                  title: "Cashed Out",
                  description: `Successfully cashed out at ${game.multiplier.toFixed(2)}x`,
                  variant: "success",
                });
              } else {
                toast({
                  title: "Cashout Failed",
                  description: "Unable to cash out at this time.",
                  variant: "destructive",
                });
              }
            }}
          />
          
          {/* Game History */}
          <GameHistory />
        </div>
        
        {/* Sidebar */}
        <div className="lg:w-1/4 p-4 md:p-6 space-y-6 border-t lg:border-t-0 lg:border-l border-border">
          {/* Live Players */}
          <LivePlayers players={game.livePlayers} />
          
          {/* Game Statistics */}
          <GameStatistics userId={game.userData?.id} />
          
          {/* Chat */}
          <GameChat />
        </div>
      </main>
      
      {/* Tutorial Modal */}
      {showTutorial && (
        <TutorialModal onClose={handleTutorialClose} />
      )}
    </div>
  );
}
